// Scroll to top button
const btnScrollToTop = document.querySelector("#btnScrollToTop");

btnScrollToTop.addEventListener("click", function () {
	window.scrollTo({
		top: 0,
		left: 0,
		behavior: "smooth",
	});
});

// Sticky navigation
const nav = document.querySelector("nav");
const navTop = nav.offsetTop;

function fixNav() {
	if (window.scrollY >= navTop) {
		document.body.style.paddingTop = nav.offsetHeight + "px";
		document.body.classList.add("fixed-nav");
	} else {
		document.body.style.paddingTop = 0;
		document.body.classList.remove("fixed-nav");
	}
}

window.addEventListener("scroll", fixNav);